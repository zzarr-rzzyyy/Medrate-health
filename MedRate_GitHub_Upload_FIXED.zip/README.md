# MedRate Android (proyek sumber)

Prototipe native Android berbasis Kotlin + Jetpack Compose.

## Fitur
- Antarmuka bahasa Indonesia, responsif, bergaya aplikasi kesehatan modern.
- Cari nama obat di web global atau DailyMed (sumber label obat AS).
- Atur pengingat pada waktu yang dipilih pengguna.
- Menggunakan AlarmManager `setAlarmClock` dan notifikasi Android.
- Pengulangan harian dasar.
- Tidak membuat rekomendasi dosis atau interval dari nama obat.

## Cara membuat APK
1. Instal Android Studio versi terbaru di PC/laptop.
2. Ekstrak proyek ZIP.
3. Android Studio > Open > pilih folder `MedRateAndroid`.
4. Tunggu Gradle sync selesai.
5. Sambungkan HP dengan USB debugging atau gunakan emulator.
6. Run untuk uji, atau Build > Build APK(s).
7. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Batasan penting
- Ini proyek sumber, bukan APK yang sudah dikompilasi dan diuji.
- Membuat APK memerlukan Android Studio/Gradle dan Android SDK.
- Android 12+ mungkin meminta izin "Alarms & reminders"; Android 13+ meminta izin notifikasi.
- Penghematan baterai, izin yang ditolak, reboot, dan setelan perangkat dapat memengaruhi pengingat.
- Prototipe belum memiliki basis data obat terstruktur, AI klinis, akun, sinkronisasi cloud, atau pengelola banyak jadwal.
- Pencarian web hanya membuka sumber luar; aplikasi tidak menginterpretasikan hasil untuk menentukan dosis.
- Jangan menggunakan contoh/hasil web untuk mengubah resep. Konsultasikan dokter/apoteker.


## Build APK lewat GitHub Actions (tanpa PC)
1. Unggah **isi ZIP ini** ke root repository GitHub, bukan ZIP ini sebagai satu file.
2. Pastikan nama branch utama `main`. File `.github/workflows/android.yml` harus ikut terunggah.
3. Buka tab **Actions** dan pilih **Build MedRate APK**.
4. Jika workflow belum berjalan otomatis, tekan **Run workflow**.
5. Setelah status sukses (hijau), buka hasil run dan unduh artifact `MedRate-debug-APK`.
6. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`.

Workflow memakai Gradle 8.9 dan JDK 17. Jika build gagal, buka log Actions; status sukses belum bisa dijamin sebelum workflow benar-benar berjalan.
