package com.medrate.app

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Calendar

private val Blue = Color(0xFF1769E0)
private val Bg = Color(0xFFF4F6FA)
private val Ink = Color(0xFF17243A)

class MainActivity : ComponentActivity() {
    private val requestNotifications = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderReceiver.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { MedRateScreen() }
    }
}

@Composable
fun MedRateScreen() {
    val context = LocalContext.current
    var medName by remember { mutableStateOf("") }
    var prescribedInstruction by remember { mutableStateOf("") }
    var hour by remember { mutableStateOf("08") }
    var minute by remember { mutableStateOf("00") }
    var repeatDaily by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("Belum ada pengingat yang dijadwalkan.") }
    var showSafety by remember { mutableStateOf(true) }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, background = Bg, surface = Color.White)
    ) {
        Column(
            Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(48.dp).background(Blue, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Text("✚", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("MedRate", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Pengingat & edukasi obat", color = Color(0xFF65748B), fontSize = 13.sp)
                }
            }
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Blue)) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Kesehatan, lebih teratur", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Atur pengingat sesuai instruksi tenaga kesehatan. Cari informasi obat dari sumber publik tepercaya.", color = Color.White)
                }
            }

            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Cari informasi obat", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                    OutlinedTextField(
                        value = medName, onValueChange = { medName = it },
                        label = { Text("Nama obat / zat aktif") },
                        placeholder = { Text("Contoh: paracetamol") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    Button(
                        onClick = {
                            val q = medName.trim()
                            if (q.isNotEmpty()) {
                                val url = "https://www.google.com/search?q=" +
                                    Uri.encode("$q official medicine information dosage warnings")
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Cari sumber global di web") }
                    OutlinedButton(
                        onClick = {
                            val q = medName.trim()
                            if (q.isNotEmpty()) context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://dailymed.nlm.nih.gov/dailymed/search.cfm?query=${Uri.encode(q)}"))
                            )
                        }, modifier = Modifier.fillMaxWidth()
                    ) { Text("Cari di DailyMed (label resmi AS)") }
                    Text(
                        "Hasil pencarian adalah bahan referensi, bukan rekomendasi dosis personal. Periksa negara, bentuk sediaan, kekuatan, usia, dan label yang sesuai.",
                        color = Color(0xFF65748B), fontSize = 12.sp
                    )
                }
            }

            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Buat pengingat", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Nama obat", color = Color(0xFF65748B), fontSize = 13.sp)
                    OutlinedTextField(value = medName, onValueChange = { medName = it }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(
                        value = prescribedInstruction, onValueChange = { prescribedInstruction = it },
                        label = { Text("Petunjuk dari resep/label (opsional)") },
                        placeholder = { Text("Masukkan sesuai instruksi dokter/apoteker") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(value = hour, onValueChange = { hour = it.filter(Char::isDigit).take(2) },
                            label = { Text("Jam (00–23)") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = minute, onValueChange = { minute = it.filter(Char::isDigit).take(2) },
                            label = { Text("Menit (00–59)") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = repeatDaily, onCheckedChange = { repeatDaily = it })
                        Text("Ulangi setiap hari")
                    }
                    Button(
                        onClick = {
                            val h = hour.toIntOrNull()
                            val m = minute.toIntOrNull()
                            if (medName.isBlank() || h == null || m == null || h !in 0..23 || m !in 0..59) {
                                status = "Periksa nama obat, jam, dan menit."
                            } else {
                                status = scheduleReminder(context, medName.trim(), prescribedInstruction.trim(), h, m, repeatDaily)
                            }
                        }, modifier = Modifier.fillMaxWidth()
                    ) { Text("Jadwalkan pengingat") }
                    Text(status, color = Blue, fontSize = 13.sp)
                    Text(
                        "Pengingat hanya mengingatkan pada waktu yang dipilih. Aplikasi tidak menentukan dosis atau interval minum otomatis.",
                        color = Color(0xFF65748B), fontSize = 12.sp
                    )
                }
            }

            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Tentang dosis dan interval", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("MedRate tidak menebak dosis dari nama obat. Informasi dosis di internet dapat berbeda menurut bentuk obat, konsentrasi, usia, kondisi kesehatan, dan negara. Ikuti resep/label serta konfirmasi kepada apoteker atau dokter.", color = Color(0xFF65748B))
                    OutlinedButton(onClick = {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.nhs.uk/medicines/")))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Buka panduan obat NHS") }
                }
            }
            Text("MedRate • Edukasi dan pengingat, bukan pengganti tenaga kesehatan.", color = Color(0xFF65748B), fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}

private fun scheduleReminder(context: Context, name: String, instruction: String, hour: Int, minute: Int, repeatDaily: Boolean): String {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        intent.data = Uri.parse("package:${context.packageName}")
        context.startActivity(intent)
        return "Izinkan alarm tepat waktu di pengaturan, lalu tekan jadwalkan lagi."
    }
    val calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    val intent = Intent(context, ReminderReceiver::class.java).apply {
        putExtra("name", name)
        putExtra("instruction", instruction)
        putExtra("repeatDaily", repeatDaily)
        putExtra("hour", hour)
        putExtra("minute", minute)
    }
    val pending = PendingIntent.getBroadcast(context, name.hashCode(), intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    alarmManager.setAlarmClock(AlarmManager.AlarmClockInfo(calendar.timeInMillis, pending), pending)
    return "Pengingat dijadwalkan untuk ${"%02d".format(hour)}:${"%02d".format(minute)}" +
        if (repeatDaily) ". Aplikasi perlu dibuka lagi untuk mengatur pengulangan harian setelah notifikasi." else "."
}
